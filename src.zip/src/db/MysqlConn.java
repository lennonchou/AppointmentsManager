package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import java.util.List;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MysqlConn {
	
	private Connection conn;

	public MysqlConn() {
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection(DBUtil.URL);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private boolean executeUpdateStatement(String query) {
		// write query to database.
		if (conn == null) {
			return false;
		}
		try {
			Statement stmt = conn.createStatement();
			System.out.println("\nDBConnection executing query:\n" + query);
			stmt.executeUpdate(query);
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	private ResultSet executeFetchStatement(String query) {
		// read query from database and return selected ones.
		if (conn == null) {
			return null;
		}
		try {
			Statement stmt = conn.createStatement();
			System.out.println("\nDBConnection executing query:\n" + query);
			return stmt.executeQuery(query);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public JSONObject getDoctorDetail(String doctorId) {		
		// TODO Auto-generated method stub
		try {
			JSONObject obj = new JSONObject();
			String query = "SELECT * FROM doctor where doctor_id='" + doctorId +"'";
			ResultSet rs = executeFetchStatement(query);
			
			//get doctor's personal info
			if (rs.next()) {
				obj.put("name", rs.getString("name")).put("picture", rs.getString("pic_url")).put("title", rs.getString("title"))
				.put("department", rs.getString("department")).put("focus", rs.getString("focus")).put("service_hospital", rs.getString("service_hospital"))
				.put("resume", rs.getString("resume")).put("price", rs.getFloat("price"));
			}
			
			//get doctor's schedule
			JSONArray calendar = new JSONArray();
			for (int i = 0; i < 2; i++) {
				for (int j = 8; j < 17; j++) {
					ResultSet status = executeFetchStatement("SELECT * FROM appointment where date='" + i +"' and time='" + j + "' and doctor_id='" + doctorId + "'");
					JSONObject slot = new JSONObject();
					if (status.next()) {
						slot.put("date", i).put("time", j).put("availability", false);
					} else {
						slot.put("date", i).put("time", j).put("availability", true);
					}
					calendar.put(slot);
				}
			}
			obj.put("calendar", calendar);
			return obj;
		} catch (JSONException | SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public JSONArray getDoctorList() {
		// TODO Auto-generated method stub
		try {
			List<String> departments = new ArrayList<>();
			String query = "SELECT DISTINCT department FROM doctor";
			ResultSet rs = executeFetchStatement(query);
			
			//get all the department name
			while (rs.next()) {
				String department = rs.getString("department");
				departments.add(department);
			}
			
			//for each department, get all the doctors in it
			JSONArray array = new JSONArray();
			for (int i = 0; i < departments.size(); i++) {
				JSONObject obj = new JSONObject().put("department", departments.get(i));
				ResultSet doctors = executeFetchStatement("SELECT * FROM doctor where department='" + departments.get(i) + "'");
				JSONArray jarr = new JSONArray();
				//put all the doctors' info in a specific department in a JSONArray
				while (doctors.next()) {
					JSONObject doctor = new JSONObject();
					doctor.put("doctor_name", doctors.getString("name")).put("doctor_pic", doctors.getString("pic_url")).put("doctor_id", doctors.getString("doctor_id"));
					jarr.put(doctor);
				}
				obj.put("doctors", jarr);
				//put one department JSONObject into result
				array.put(obj);
			}
			return array;
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(SQLException e) {
			e.printStackTrace();
		}
		System.out.print("no list");
		return null;
	}

	public boolean setSelectedAppointment(String doctorId, int date, int time, String name, String gender, String phoneNo, String problem) {
		String query = "INSERT INTO appointment VALUES(\"" + doctorId + "\",\"" + name + "\",\"" + date + "\",\"" + time + "\",\"" + gender + "\",\""
				+ phoneNo +"\",\"" + problem + "\")";
		if (!executeUpdateStatement(query)) {
			return false;
		}
		return true;
	}

	public JSONArray getAppointment(String doctorId) throws JSONException {
		// TODO Auto-generated method stub		
		try {
			JSONArray array = new JSONArray();
			ResultSet rs = executeFetchStatement("SELECT * FROM appointment where doctor_id='" + doctorId + "'");
			while (rs.next()) {
				
				//get each appointment slot
				JSONObject slot = new JSONObject();
				slot.put("date", rs.getInt("date")).put("time", rs.getInt("time"))
				.put("patient_name", rs.getString("patient_name")).put("description_of_problem", rs.getString("description_of_problem"));
				array.put(slot);
			}
			return array;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public static void main(String[] args) throws JSONException {
//		MysqlConn c = new MysqlConn();
//		if (c.setSelectedAppointment("D021", 1, 9, "", "", "", "")) {
//			System.out.println("YES");
//		}
//		System.out.println(c.getDoctorDetail("D021").toString());
//		System.out.println(c.getDoctorList().toString());
	}
}
